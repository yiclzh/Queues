import edu.princeton.cs.algs4.StdIn;

public class Permutation {
    public static void main(String[] args) {
        RandomizedQueue randomizedQueue = new RandomizedQueue();
        int k = Integer.parseInt(args[0]);
        System.out.println(k);
        while (!StdIn.isEmpty()) {
            String input = StdIn.readString();
            randomizedQueue.enqueue(input);
        }
        for (int i = 0; i < k; i++) {
            Object s = randomizedQueue.dequeue();
            while (s == null) {
                s = randomizedQueue.dequeue();
            }
            System.out.println(s);
        }

    }
}
